<?php

$host = '/flox-social-backend/';
?>